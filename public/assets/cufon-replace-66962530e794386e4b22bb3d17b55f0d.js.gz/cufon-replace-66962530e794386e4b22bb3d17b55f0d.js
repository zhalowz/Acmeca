Cufon.replace('.menu a', { fontFamily: 'Myriad Pro Regular', hover:true, textShadow: '0px 0px #515151' });
Cufon.replace('h3, #form-2 strong, #ContactForm strong, h2', { fontFamily: 'Myriad Pro Regular' });
Cufon.replace('h4', { fontFamily: 'Myriad Pro Semibold', hover:true });
Cufon.replace('h5', { fontFamily: 'Myriad Pro Light', hover:true });
